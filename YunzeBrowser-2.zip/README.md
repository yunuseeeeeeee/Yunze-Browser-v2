# Yunze Browser

Android için gelişmiş, güvenlik odaklı bir web tarayıcısı. Kotlin ve Android WebView üzerine inşa edilmiştir.

## Özellikler

- **Çoklu sekme** yönetimi (normal + gizli sekmeler)
- **Gizli Mod (Incognito)**: geçmiş kaydedilmez, DOM depolama kapalı, sekme kapanınca çerezler temizlenir
- **Reklam & izleyici engelleme**: `assets/blocklist.txt` içindeki bilinen domain listesine göre
- **Site izin yönetimi**: kamera, mikrofon, konum izinleri site bazında hatırlanır ve Ayarlar > Site İzinleri'nden yönetilebilir
- **SSL/TLS uyarıları**: geçersiz sertifikalarda kullanıcıya onay sorulur, otomatik geçiş yapılmaz
- **HTTPS'e zorla** ayarı: mümkün olduğunda siteleri otomatik https ile açar
- **Pop-up engelleme**
- **Yer imleri** ve **geçmiş** yönetimi
- **İndirme** desteği (Android DownloadManager üzerinden)
- Material Design temelli, koyu/mor temalı gizli mod arayüzü

## Proje Yapısı

```
YunzeBrowser/
├── app/
│   ├── src/main/java/com/yunze/browser/   <- Kotlin kaynak kodu
│   ├── src/main/res/                      <- Layout, drawable, string kaynakları
│   └── src/main/assets/blocklist.txt      <- Reklam/izleyici domain listesi
├── .github/workflows/build.yml            <- GitHub Actions CI/CD
├── build.gradle.kts
└── settings.gradle.kts
```

## GitHub Actions ile Derleme

1. Bu klasörün tamamını (zip içeriğini) yeni bir GitHub reposuna push'la.
2. `Actions` sekmesine git, workflow otomatik tetiklenecek (push ile) ya da `Run workflow` ile manuel başlat.
3. Derleme bitince **Artifacts** bölümünden:
   - `yunze-browser-debug` → doğrudan telefona kurulabilen debug APK
   - `yunze-browser-release-unsigned` → imzasız release APK (yayınlamadan önce imzalanmalı)

## Bilinen Sınırlamalar (v1)

- Gizli mod, tam profil izolasyonu değil; DOM storage kapalı ve geçmiş kaydı yok, ancak WebView'in global çerez yöneticisi paylaşıldığından son gizli sekme kapanınca tüm çerezler temizlenir (normal sekmelerinki de dahil). İleri sürümde per-tab cookie jar (API 30+ `WebViewCookieManager` ayrımı) eklenecek.
- Reklam engelleme, DNS tabanlı basit bir liste ile çalışır (EasyList tarzı kural motoru değil).
- Dosya seçici (file input) tek dosya seçimini destekler, çoklu seçim yok.

## Sonraki Adımlar İçin Fikirler

- Sekme önizleme thumbnail'leri
- Ayarlanabilir tema (açık/koyu/otomatik)
- Kendi arama motorunu ekleme
- Şifre yöneticisi entegrasyonu
