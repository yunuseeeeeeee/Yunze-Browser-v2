# Yunze Browser proguard rules
-keep class com.yunze.browser.** { *; }
