package com.yunze.browser

import android.content.Context
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.net.URI

/**
 * assets/blocklist.txt dosyasından yüklenen bilinen reklam/izleyici
 * domain listesine göre istekleri engelleyen basit ama etkili bir motor.
 */
class AdBlocker(context: Context) {

    private val blockedHosts = HashSet<String>()

    init {
        try {
            context.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
                for (line in lines) {
                    val trimmed = line.trim()
                    if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                        blockedHosts.add(trimmed.lowercase())
                    }
                }
            }
        } catch (e: Exception) {
            // Liste yüklenemezse engelleme sessizce devre dışı kalır
        }
    }

    fun isBlocked(url: String): Boolean {
        if (blockedHosts.isEmpty()) return false
        val host = try {
            URI(url).host?.lowercase()
        } catch (e: Exception) {
            null
        } ?: return false

        // Tam eşleşme veya üst domain eşleşmesi (örn. ads.example.com -> example.com engelliyse)
        var current = host
        while (true) {
            if (blockedHosts.contains(current)) return true
            val dotIndex = current.indexOf('.')
            if (dotIndex == -1) break
            current = current.substring(dotIndex + 1)
        }
        return false
    }

    fun blockedResponse(): WebResourceResponse {
        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
    }
}
