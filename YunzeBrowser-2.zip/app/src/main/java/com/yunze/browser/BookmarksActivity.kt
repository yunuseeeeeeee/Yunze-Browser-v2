package com.yunze.browser

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.yunze.browser.databinding.ActivityBookmarksBinding

class BookmarksActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBookmarksBinding
    private lateinit var dataStore: DataStore
    private lateinit var adapter: BookmarkAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookmarksBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dataStore = DataStore(this)
        binding.btnBack.setOnClickListener { finish() }

        adapter = BookmarkAdapter(
            onOpen = { entry ->
                val intent = Intent(this, MainActivity::class.java)
                intent.data = android.net.Uri.parse(entry.url)
                intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                startActivity(intent)
                finish()
            },
            onDelete = { entry ->
                dataStore.removeBookmark(entry.url)
                refresh()
            }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val items = dataStore.getBookmarks()
        adapter.submitList(items)
        binding.emptyState.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}

class BookmarkAdapter(
    private val onOpen: (BookmarkEntry) -> Unit,
    private val onDelete: (BookmarkEntry) -> Unit
) : RecyclerView.Adapter<BookmarkAdapter.VH>() {

    private var items: List<BookmarkEntry> = emptyList()

    fun submitList(newItems: List<BookmarkEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list_entry, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.title.text = item.title
        holder.subtitle.text = item.url
        holder.icon.setImageResource(R.drawable.ic_star_filled)
        holder.itemView.setOnClickListener { onOpen(item) }
        holder.deleteBtn.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount(): Int = items.size

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.entryTitle)
        val subtitle: TextView = itemView.findViewById(R.id.entrySubtitle)
        val icon: ImageView = itemView.findViewById(R.id.entryIcon)
        val deleteBtn: View = itemView.findViewById(R.id.btnEntryDelete)
    }
}
