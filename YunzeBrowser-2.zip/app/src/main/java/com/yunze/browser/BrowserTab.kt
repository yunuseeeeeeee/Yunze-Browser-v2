package com.yunze.browser

import android.webkit.WebView

/**
 * Tek bir tarayıcı sekmesini temsil eder. Her sekmenin kendi WebView'i vardır.
 */
data class BrowserTabModel(
    val id: Long,
    var webView: WebView,
    var title: String = "Yeni Sekme",
    var url: String = "",
    var isSecure: Boolean = false,
    val isIncognito: Boolean = false,
    var favicon: android.graphics.Bitmap? = null
)
