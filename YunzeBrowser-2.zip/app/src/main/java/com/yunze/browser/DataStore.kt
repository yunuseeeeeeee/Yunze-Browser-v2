package com.yunze.browser

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class BookmarkEntry(val title: String, val url: String)
data class HistoryEntry(val title: String, val url: String, val timestamp: Long)
data class SitePermission(val origin: String, val type: String, val granted: Boolean)

/**
 * Uygulamanın tüm kalıcı verilerini (yer imleri, geçmiş, site izinleri, ayarlar)
 * SharedPreferences üzerinden JSON olarak yöneten yardımcı sınıf.
 */
class DataStore(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ---------------- Yer İmleri ----------------

    fun getBookmarks(): List<BookmarkEntry> {
        val raw = prefs.getString(KEY_BOOKMARKS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val result = mutableListOf<BookmarkEntry>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            result.add(BookmarkEntry(obj.optString("title"), obj.optString("url")))
        }
        return result.reversed()
    }

    fun isBookmarked(url: String): Boolean = getBookmarks().any { it.url == url }

    fun addBookmark(title: String, url: String) {
        if (isBookmarked(url)) return
        val raw = prefs.getString(KEY_BOOKMARKS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val obj = JSONObject()
        obj.put("title", if (title.isBlank()) url else title)
        obj.put("url", url)
        arr.put(obj)
        prefs.edit().putString(KEY_BOOKMARKS, arr.toString()).apply()
    }

    fun removeBookmark(url: String) {
        val raw = prefs.getString(KEY_BOOKMARKS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val newArr = JSONArray()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            if (obj.optString("url") != url) newArr.put(obj)
        }
        prefs.edit().putString(KEY_BOOKMARKS, newArr.toString()).apply()
    }

    // ---------------- Geçmiş ----------------

    fun getHistory(): List<HistoryEntry> {
        val raw = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val result = mutableListOf<HistoryEntry>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            result.add(
                HistoryEntry(
                    obj.optString("title"),
                    obj.optString("url"),
                    obj.optLong("timestamp")
                )
            )
        }
        return result.reversed()
    }

    fun addHistory(title: String, url: String) {
        if (url.isBlank() || url.startsWith("about:")) return
        val raw = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val obj = JSONObject()
        obj.put("title", if (title.isBlank()) url else title)
        obj.put("url", url)
        obj.put("timestamp", System.currentTimeMillis())
        arr.put(obj)

        // Son 500 kaydı tut
        val trimmed = if (arr.length() > MAX_HISTORY) {
            val newArr = JSONArray()
            val start = arr.length() - MAX_HISTORY
            for (i in start until arr.length()) newArr.put(arr.get(i))
            newArr
        } else arr

        prefs.edit().putString(KEY_HISTORY, trimmed.toString()).apply()
    }

    fun clearHistory() {
        prefs.edit().putString(KEY_HISTORY, "[]").apply()
    }

    fun removeHistoryEntry(url: String, timestamp: Long) {
        val raw = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val newArr = JSONArray()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            if (!(obj.optString("url") == url && obj.optLong("timestamp") == timestamp)) {
                newArr.put(obj)
            }
        }
        prefs.edit().putString(KEY_HISTORY, newArr.toString()).apply()
    }

    // ---------------- Site İzinleri ----------------

    fun getPermissions(): List<SitePermission> {
        val raw = prefs.getString(KEY_PERMISSIONS, "{}") ?: "{}"
        val obj = JSONObject(raw)
        val result = mutableListOf<SitePermission>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val parts = key.split("::")
            if (parts.size == 2) {
                result.add(SitePermission(parts[0], parts[1], obj.optBoolean(key)))
            }
        }
        return result
    }

    fun getPermission(origin: String, type: String): Boolean? {
        val raw = prefs.getString(KEY_PERMISSIONS, "{}") ?: "{}"
        val obj = JSONObject(raw)
        val key = "$origin::$type"
        return if (obj.has(key)) obj.getBoolean(key) else null
    }

    fun setPermission(origin: String, type: String, granted: Boolean) {
        val raw = prefs.getString(KEY_PERMISSIONS, "{}") ?: "{}"
        val obj = JSONObject(raw)
        obj.put("$origin::$type", granted)
        prefs.edit().putString(KEY_PERMISSIONS, obj.toString()).apply()
    }

    fun removePermission(origin: String, type: String) {
        val raw = prefs.getString(KEY_PERMISSIONS, "{}") ?: "{}"
        val obj = JSONObject(raw)
        obj.remove("$origin::$type")
        prefs.edit().putString(KEY_PERMISSIONS, obj.toString()).apply()
    }

    // ---------------- Ayarlar ----------------

    var adBlockEnabled: Boolean
        get() = prefs.getBoolean(KEY_AD_BLOCK, true)
        set(value) = prefs.edit().putBoolean(KEY_AD_BLOCK, value).apply()

    var javaScriptEnabled: Boolean
        get() = prefs.getBoolean(KEY_JS, true)
        set(value) = prefs.edit().putBoolean(KEY_JS, value).apply()

    var httpsUpgradeEnabled: Boolean
        get() = prefs.getBoolean(KEY_HTTPS_UPGRADE, true)
        set(value) = prefs.edit().putBoolean(KEY_HTTPS_UPGRADE, value).apply()

    var popupBlockEnabled: Boolean
        get() = prefs.getBoolean(KEY_POPUP_BLOCK, true)
        set(value) = prefs.edit().putBoolean(KEY_POPUP_BLOCK, value).apply()

    var doNotTrackEnabled: Boolean
        get() = prefs.getBoolean(KEY_DNT, true)
        set(value) = prefs.edit().putBoolean(KEY_DNT, value).apply()

    var searchEngine: String
        get() = prefs.getString(KEY_SEARCH_ENGINE, SearchEngine.GOOGLE.id) ?: SearchEngine.GOOGLE.id
        set(value) = prefs.edit().putString(KEY_SEARCH_ENGINE, value).apply()

    fun clearAllData() {
        prefs.edit()
            .remove(KEY_BOOKMARKS)
            .remove(KEY_HISTORY)
            .remove(KEY_PERMISSIONS)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "yunze_prefs"
        private const val KEY_BOOKMARKS = "bookmarks"
        private const val KEY_HISTORY = "history"
        private const val KEY_PERMISSIONS = "permissions"
        private const val KEY_AD_BLOCK = "ad_block_enabled"
        private const val KEY_JS = "js_enabled"
        private const val KEY_HTTPS_UPGRADE = "https_upgrade_enabled"
        private const val KEY_POPUP_BLOCK = "popup_block_enabled"
        private const val KEY_DNT = "do_not_track_enabled"
        private const val KEY_SEARCH_ENGINE = "search_engine"
        private const val MAX_HISTORY = 500
    }
}

enum class SearchEngine(val id: String, val displayName: String, val searchUrl: String) {
    GOOGLE("google", "Google", "https://www.google.com/search?q="),
    BING("bing", "Bing", "https://www.bing.com/search?q="),
    DUCKDUCKGO("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q="),
    YANDEX("yandex", "Yandex", "https://yandex.com/search/?text=");

    companion object {
        fun fromId(id: String): SearchEngine = values().find { it.id == id } ?: GOOGLE
    }
}
