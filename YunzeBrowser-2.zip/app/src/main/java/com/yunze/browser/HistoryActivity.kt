package com.yunze.browser

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.yunze.browser.databinding.ActivityHistoryBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var dataStore: DataStore
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dataStore = DataStore(this)
        binding.btnBack.setOnClickListener { finish() }
        binding.btnClearAll.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.clear_history)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    dataStore.clearHistory()
                    refresh()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }

        adapter = HistoryAdapter(
            onOpen = { entry ->
                val intent = Intent(this, MainActivity::class.java)
                intent.data = android.net.Uri.parse(entry.url)
                intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                startActivity(intent)
                finish()
            },
            onDelete = { entry ->
                dataStore.removeHistoryEntry(entry.url, entry.timestamp)
                refresh()
            }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
        refresh()
    }

    private fun refresh() {
        val items = dataStore.getHistory()
        adapter.submitList(items)
        binding.emptyState.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}

class HistoryAdapter(
    private val onOpen: (HistoryEntry) -> Unit,
    private val onDelete: (HistoryEntry) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.VH>() {

    private var items: List<HistoryEntry> = emptyList()
    private val dateFormat = SimpleDateFormat("d MMM, HH:mm", Locale("tr"))

    fun submitList(newItems: List<HistoryEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list_entry, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.title.text = item.title
        holder.subtitle.text = dateFormat.format(Date(item.timestamp)) + " · " + item.url
        holder.icon.setImageResource(R.drawable.ic_search)
        holder.itemView.setOnClickListener { onOpen(item) }
        holder.deleteBtn.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount(): Int = items.size

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.entryTitle)
        val subtitle: TextView = itemView.findViewById(R.id.entrySubtitle)
        val icon: ImageView = itemView.findViewById(R.id.entryIcon)
        val deleteBtn: View = itemView.findViewById(R.id.btnEntryDelete)
    }
}
