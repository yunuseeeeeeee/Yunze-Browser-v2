package com.yunze.browser

import android.Manifest
import android.app.DownloadManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.yunze.browser.databinding.ActivityMainBinding
import com.yunze.browser.databinding.DialogPermissionRequestBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var dataStore: DataStore
    private lateinit var adBlocker: AdBlocker
    private lateinit var tabAdapter: TabAdapter

    private val tabs = mutableListOf<BrowserTabModel>()
    private var currentTabIndex = -1
    private var nextTabId = 1L

    // Bekleyen izin istekleri
    private var pendingWebPermissionRequest: PermissionRequest? = null
    private var pendingGeoRequest: Pair<String, GeolocationPermissions.Callback>? = null
    private var pendingFileChooserCallback: ValueCallback<Array<Uri>>? = null

    private val runtimePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            val allGranted = results.values.all { it }
            val webRequest = pendingWebPermissionRequest
            val geoRequest = pendingGeoRequest
            pendingWebPermissionRequest = null
            pendingGeoRequest = null
            if (webRequest != null) {
                if (allGranted) showSitePermissionDialog(webRequest) else webRequest.deny()
            } else if (geoRequest != null) {
                if (allGranted) showGeoPermissionDialog(geoRequest.first, geoRequest.second)
                else geoRequest.second.invoke(geoRequest.first, false, false)
            }
        }

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                pendingFileChooserCallback?.onReceiveValue(arrayOf(uri))
            } else {
                pendingFileChooserCallback?.onReceiveValue(null)
            }
            pendingFileChooserCallback = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dataStore = DataStore(this)
        adBlocker = AdBlocker(this)

        setupToolbar()
        setupTabSwitcher()
        setupBackPress()

        val incomingUrl = intent?.dataString
        addTab(incomingUrl ?: HOME_URL, incognito = false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.dataString
        if (url != null) {
            addTab(url, incognito = false)
        }
    }

    // ------------------------------------------------------------------
    // Kurulum
    // ------------------------------------------------------------------

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener { currentWebView()?.let { if (it.canGoBack()) it.goBack() } }
        binding.btnForward.setOnClickListener { currentWebView()?.let { if (it.canGoForward()) it.goForward() } }
        binding.btnReload.setOnClickListener {
            val wv = currentWebView() ?: return@setOnClickListener
            if (wv.progress in 1..99) wv.stopLoading() else wv.reload()
        }
        binding.btnAddTab.setOnClickListener { addTab(HOME_URL, incognito = false) }
        binding.btnTabs.setOnClickListener { showTabSwitcher() }
        binding.btnMenu.setOnClickListener { showMainMenu(it) }
        binding.btnBookmarkStar.setOnClickListener { toggleBookmarkForCurrentTab() }

        binding.addressBar.setOnEditorActionListener { textView, actionId, event ->
            val isEnter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_GO || isEnter) {
                loadInput(textView.text.toString())
                hideKeyboard()
                binding.addressBar.clearFocus()
                true
            } else false
        }

        binding.addressBar.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                binding.addressBar.selectAll()
            } else {
                currentTabOrNull()?.let { binding.addressBar.setText(it.url) }
            }
        }
    }

    private fun setupTabSwitcher() {
        val overlay = binding.tabSwitcherOverlay
        tabAdapter = TabAdapter(
            onTabClick = { index -> switchToTab(index); hideTabSwitcher() },
            onTabClose = { index -> closeTab(index) }
        )
        overlay.tabRecyclerView.layoutManager = LinearLayoutManager(this)
        overlay.tabRecyclerView.adapter = tabAdapter

        overlay.btnCloseTabSwitcher.setOnClickListener { hideTabSwitcher() }
        overlay.btnNewTabFromSwitcher.setOnClickListener {
            addTab(HOME_URL, incognito = false)
            hideTabSwitcher()
        }
        overlay.btnNewIncognitoFromSwitcher.setOnClickListener {
            addTab(HOME_URL, incognito = true)
            hideTabSwitcher()
        }
        overlay.btnCloseAllTabs.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.close_all_tabs)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    while (tabs.isNotEmpty()) closeTab(0)
                    addTab(HOME_URL, incognito = false)
                    hideTabSwitcher()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    private fun setupBackPress() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val overlay = binding.tabSwitcherOverlay.tabSwitcherRoot
                when {
                    overlay.visibility == View.VISIBLE -> hideTabSwitcher()
                    currentWebView()?.canGoBack() == true -> currentWebView()?.goBack()
                    tabs.size > 1 -> closeTab(currentTabIndex)
                    else -> finish()
                }
            }
        })
    }

    // ------------------------------------------------------------------
    // Sekme Yönetimi
    // ------------------------------------------------------------------

    private fun currentWebView(): WebView? = tabs.getOrNull(currentTabIndex)?.webView
    private fun currentTabOrNull(): BrowserTabModel? = tabs.getOrNull(currentTabIndex)

    private fun addTab(url: String, incognito: Boolean, background: Boolean = false): BrowserTabModel {
        val webView = createWebView(incognito)
        val tab = BrowserTabModel(id = nextTabId++, webView = webView, isIncognito = incognito)
        tabs.add(tab)
        binding.webViewContainer.addView(
            webView,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        webView.visibility = View.GONE

        val target = if (URLUtil.isValidUrl(url)) url else HOME_URL
        webView.loadUrl(target)

        if (!background) {
            switchToTab(tabs.indexOf(tab))
        }
        updateEmptyState()
        return tab
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        tabs.forEachIndexed { i, t -> t.webView.visibility = if (i == index) View.VISIBLE else View.GONE }
        currentTabIndex = index
        val tab = tabs[index]
        applyTabTheme(tab.isIncognito)
        binding.addressBar.setText(tab.url)
        updateNavButtons()
        updateSecurityIcon(tab.isSecure)
        updateBookmarkStar(tab.url)
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        binding.webViewContainer.removeView(tab.webView)
        tab.webView.stopLoading()
        tab.webView.destroy()
        tabs.removeAt(index)

        if (tab.isIncognito && tabs.none { it.isIncognito }) {
            // Son gizli sekme kapandığında çerezleri temizle
            CookieManager.getInstance().removeAllCookies(null)
        }

        if (tabs.isEmpty()) {
            currentTabIndex = -1
            updateEmptyState()
            addTab(HOME_URL, incognito = false)
            return
        }

        val newIndex = when {
            currentTabIndex > index -> currentTabIndex - 1
            currentTabIndex == index -> index.coerceAtMost(tabs.size - 1)
            else -> currentTabIndex
        }
        switchToTab(newIndex)
        tabAdapter.submitList(tabs.toList())
        updateEmptyState()
    }

    private fun updateEmptyState() {
        binding.emptyState.visibility = if (tabs.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showTabSwitcher() {
        tabAdapter.submitList(tabs.toList())
        binding.tabSwitcherOverlay.tabSwitcherRoot.visibility = View.VISIBLE
    }

    private fun hideTabSwitcher() {
        binding.tabSwitcherOverlay.tabSwitcherRoot.visibility = View.GONE
    }

    private fun applyTabTheme(isIncognito: Boolean) {
        val bgColor = ContextCompat.getColor(this, if (isIncognito) R.color.incognito_bg else R.color.brand_primary)
        binding.topBar.setBackgroundColor(bgColor)
        window.statusBarColor = ContextCompat.getColor(
            this,
            if (isIncognito) R.color.incognito_bg_dark else R.color.brand_primary_dark
        )
    }

    // ------------------------------------------------------------------
    // WebView Oluşturma
    // ------------------------------------------------------------------

    private fun createWebView(incognito: Boolean): WebView {
        val webView = WebView(this)
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = dataStore.javaScriptEnabled
        settings.domStorageEnabled = !incognito
        settings.databaseEnabled = !incognito
        settings.cacheMode = if (incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = !dataStore.popupBlockEnabled
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.mediaPlaybackRequiresUserGesture = true
        settings.allowFileAccess = false
        settings.allowContentAccess = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.setGeolocationEnabled(true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.safeBrowsingEnabled = true
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, !dataStore.doNotTrackEnabled)

        webView.webViewClient = BrowserWebViewClient(incognito)
        webView.webChromeClient = BrowserWebChromeClient()
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(url, userAgent, contentDisposition, mimeType)
        }
        return webView
    }

    // ------------------------------------------------------------------
    // WebViewClient / WebChromeClient
    // ------------------------------------------------------------------

    private inner class BrowserWebViewClient(private val incognito: Boolean) : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url.toString()
            val scheme = request.url.scheme ?: ""
            if (scheme == "http" && dataStore.httpsUpgradeEnabled && request.isForMainFrame) {
                view.loadUrl("https://" + url.removePrefix("http://"))
                return true
            }
            if (scheme == "http" || scheme == "https") {
                return false
            }
            return try {
                val intent = Intent(Intent.ACTION_VIEW, request.url)
                startActivity(intent)
                true
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, url, Toast.LENGTH_SHORT).show()
                true
            }
        }

        override fun shouldInterceptRequest(
            view: WebView,
            request: WebResourceRequest
        ): WebResourceResponse? {
            if (dataStore.adBlockEnabled && request.url != null) {
                if (adBlocker.isBlocked(request.url.toString())) {
                    return adBlocker.blockedResponse()
                }
            }
            return super.shouldInterceptRequest(view, request)
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            val tab = tabs.find { it.webView == view } ?: return
            tab.url = url ?: tab.url
            tab.isSecure = url?.startsWith("https://") == true
            if (isCurrent(tab)) {
                if (!binding.addressBar.hasFocus()) binding.addressBar.setText(tab.url)
                updateSecurityIcon(tab.isSecure)
                updateNavButtons()
                updateBookmarkStar(tab.url)
                binding.progressBar.visibility = View.VISIBLE
            }
        }

        override fun onPageFinished(view: WebView, url: String?) {
            super.onPageFinished(view, url)
            val tab = tabs.find { it.webView == view } ?: return
            tab.title = view.title ?: url ?: ""
            tab.url = url ?: tab.url
            if (!incognito) {
                dataStore.addHistory(tab.title, tab.url)
            }
            if (isCurrent(tab)) {
                binding.progressBar.visibility = View.GONE
                updateNavButtons()
                updateBookmarkStar(tab.url)
            }
        }

        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.ssl_warning_title)
                .setMessage(R.string.ssl_warning_message)
                .setCancelable(false)
                .setPositiveButton(R.string.proceed_anyway) { _, _ -> handler.proceed() }
                .setNegativeButton(R.string.go_back_safety) { _, _ -> handler.cancel() }
                .show()
        }
    }

    private inner class BrowserWebChromeClient : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            super.onProgressChanged(view, newProgress)
            val tab = tabs.find { it.webView == view } ?: return
            if (isCurrent(tab)) {
                binding.progressBar.progress = newProgress
                binding.progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            super.onReceivedTitle(view, title)
            val tab = tabs.find { it.webView == view } ?: return
            tab.title = title ?: tab.url
        }

        override fun onPermissionRequest(request: PermissionRequest) {
            runOnUiThread {
                val neededAndroidPermissions = mutableListOf<String>()
                for (resource in request.resources) {
                    when (resource) {
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> neededAndroidPermissions.add(Manifest.permission.CAMERA)
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> neededAndroidPermissions.add(Manifest.permission.RECORD_AUDIO)
                    }
                }
                val missing = neededAndroidPermissions.filter {
                    ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                }
                if (missing.isNotEmpty()) {
                    pendingWebPermissionRequest = request
                    runtimePermissionLauncher.launch(missing.toTypedArray())
                } else {
                    showSitePermissionDialog(request)
                }
            }
        }

        override fun onGeolocationPermissionsShowPrompt(
            origin: String,
            callback: GeolocationPermissions.Callback
        ) {
            val missing = ContextCompat.checkSelfPermission(
                this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
            if (missing) {
                pendingGeoRequest = origin to callback
                runtimePermissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
            } else {
                showGeoPermissionDialog(origin, callback)
            }
        }

        override fun onCreateWindow(
            view: WebView,
            isDialog: Boolean,
            isUserGesture: Boolean,
            resultMsg: android.os.Message
        ): Boolean {
            if (dataStore.popupBlockEnabled && !isUserGesture) {
                return false
            }
            val incognito = tabs.find { it.webView == view }?.isIncognito ?: false
            val newTab = addTab("about:blank", incognito = incognito)
            val transport = resultMsg.obj as WebView.WebViewTransport
            transport.webView = newTab.webView
            resultMsg.sendToTarget()
            return true
        }

        override fun onShowFileChooser(
            webView: WebView,
            filePathCallback: ValueCallback<Array<Uri>>,
            fileChooserParams: FileChooserParams
        ): Boolean {
            pendingFileChooserCallback = filePathCallback
            return try {
                fileChooserLauncher.launch("*/*")
                true
            } catch (e: Exception) {
                pendingFileChooserCallback = null
                false
            }
        }
    }

    // ------------------------------------------------------------------
    // İzin Diyalogları
    // ------------------------------------------------------------------

    private fun showSitePermissionDialog(request: PermissionRequest) {
        val origin = request.origin.toString()
        val types = request.resources.mapNotNull {
            when (it) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera"
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "mic"
                else -> null
            }
        }

        val remembered = types.map { dataStore.getPermission(origin, it) }
        if (remembered.all { it == true }) {
            request.grant(request.resources)
            return
        }
        if (remembered.any { it == false }) {
            request.deny()
            return
        }

        val label = types.joinToString(" & ") {
            if (it == "camera") getString(R.string.permission_camera) else getString(R.string.permission_mic)
        }
        val dialogBinding = DialogPermissionRequestBinding.inflate(layoutInflater)
        dialogBinding.dialogOrigin.text = origin
        dialogBinding.dialogMessage.text = getString(R.string.permission_request_title) + ": $label"

        AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setCancelable(false)
            .setPositiveButton(R.string.permission_allow) { _, _ ->
                request.grant(request.resources)
                if (dialogBinding.dialogRememberCheck.isChecked) {
                    types.forEach { dataStore.setPermission(origin, it, true) }
                }
            }
            .setNegativeButton(R.string.permission_deny) { _, _ ->
                request.deny()
                if (dialogBinding.dialogRememberCheck.isChecked) {
                    types.forEach { dataStore.setPermission(origin, it, false) }
                }
            }
            .show()
    }

    private fun showGeoPermissionDialog(origin: String, callback: GeolocationPermissions.Callback) {
        val remembered = dataStore.getPermission(origin, "location")
        if (remembered == true) {
            callback.invoke(origin, true, false)
            return
        }
        if (remembered == false) {
            callback.invoke(origin, false, false)
            return
        }

        val dialogBinding = DialogPermissionRequestBinding.inflate(layoutInflater)
        dialogBinding.dialogOrigin.text = origin
        dialogBinding.dialogMessage.text =
            getString(R.string.permission_request_title) + ": " + getString(R.string.permission_location)

        AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setCancelable(false)
            .setPositiveButton(R.string.permission_allow) { _, _ ->
                callback.invoke(origin, true, dialogBinding.dialogRememberCheck.isChecked)
                if (dialogBinding.dialogRememberCheck.isChecked) dataStore.setPermission(origin, "location", true)
            }
            .setNegativeButton(R.string.permission_deny) { _, _ ->
                callback.invoke(origin, false, dialogBinding.dialogRememberCheck.isChecked)
                if (dialogBinding.dialogRememberCheck.isChecked) dataStore.setPermission(origin, "location", false)
            }
            .show()
    }

    // ------------------------------------------------------------------
    // İndirmeler
    // ------------------------------------------------------------------

    private fun startDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String) {
        try {
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val request = DownloadManager.Request(Uri.parse(url))
            request.setMimeType(mimeType)
            val cookies = CookieManager.getInstance().getCookie(url)
            request.addRequestHeader("cookie", cookies)
            request.addRequestHeader("User-Agent", userAgent)
            request.setDescription(getString(R.string.app_name))
            request.setTitle(fileName)
            request.allowScanningByMediaScanner()
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, fileName)
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            Toast.makeText(this, fileName, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e(TAG, "İndirme başarısız", e)
            Toast.makeText(this, "İndirme başlatılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------
    // Adres Çubuğu / Navigasyon
    // ------------------------------------------------------------------

    private fun loadInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        val target = when {
            URLUtil.isValidUrl(trimmed) -> trimmed
            looksLikeUrl(trimmed) -> "https://$trimmed"
            else -> {
                val engine = SearchEngine.fromId(dataStore.searchEngine)
                engine.searchUrl + Uri.encode(trimmed)
            }
        }
        currentWebView()?.loadUrl(target)
    }

    private fun looksLikeUrl(text: String): Boolean {
        if (text.contains(" ")) return false
        return text.contains(".") && !text.contains("..")
    }

    private fun updateNavButtons() {
        val wv = currentWebView()
        binding.btnBack.alpha = if (wv?.canGoBack() == true) 1f else 0.35f
        binding.btnForward.alpha = if (wv?.canGoForward() == true) 1f else 0.35f
    }

    private fun updateSecurityIcon(secure: Boolean) {
        binding.securityIcon.setImageResource(if (secure) R.drawable.ic_lock else R.drawable.ic_warning)
    }

    private fun updateBookmarkStar(url: String) {
        val bookmarked = dataStore.isBookmarked(url)
        binding.btnBookmarkStar.setImageResource(if (bookmarked) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
    }

    private fun toggleBookmarkForCurrentTab() {
        val tab = currentTabOrNull() ?: return
        if (dataStore.isBookmarked(tab.url)) {
            dataStore.removeBookmark(tab.url)
        } else {
            dataStore.addBookmark(tab.title, tab.url)
            Toast.makeText(this, R.string.add_bookmark_success, Toast.LENGTH_SHORT).show()
        }
        updateBookmarkStar(tab.url)
    }

    private fun isCurrent(tab: BrowserTabModel): Boolean = tabs.getOrNull(currentTabIndex)?.id == tab.id

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.addressBar.windowToken, 0)
    }

    // ------------------------------------------------------------------
    // Menü
    // ------------------------------------------------------------------

    private fun showMainMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.main_menu, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_new_tab -> addTab(HOME_URL, incognito = false)
                R.id.action_new_incognito -> addTab(HOME_URL, incognito = true)
                R.id.action_bookmarks -> startActivity(Intent(this, BookmarksActivity::class.java))
                R.id.action_add_bookmark -> toggleBookmarkForCurrentTab()
                R.id.action_history -> startActivity(Intent(this, HistoryActivity::class.java))
                R.id.action_share -> shareCurrentUrl()
                R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            }
            true
        }
        popup.show()
    }

    private fun shareCurrentUrl() {
        val url = currentTabOrNull()?.url ?: return
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        intent.putExtra(Intent.EXTRA_TEXT, url)
        startActivity(Intent.createChooser(intent, getString(R.string.menu_share)))
    }

    override fun onDestroy() {
        tabs.forEach { it.webView.destroy() }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "YunzeBrowser"
        const val HOME_URL = "https://www.google.com"
    }
}
