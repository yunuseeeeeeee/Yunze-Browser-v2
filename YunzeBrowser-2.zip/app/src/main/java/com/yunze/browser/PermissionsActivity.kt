package com.yunze.browser

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.yunze.browser.databinding.ActivityPermissionsBinding

class PermissionsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionsBinding
    private lateinit var dataStore: DataStore
    private lateinit var adapter: PermissionAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dataStore = DataStore(this)
        binding.btnBack.setOnClickListener { finish() }

        adapter = PermissionAdapter { perm ->
            dataStore.removePermission(perm.origin, perm.type)
            refresh()
        }
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
        refresh()
    }

    private fun refresh() {
        val items = dataStore.getPermissions()
        adapter.submitList(items)
        binding.emptyState.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}

class PermissionAdapter(
    private val onDelete: (SitePermission) -> Unit
) : RecyclerView.Adapter<PermissionAdapter.VH>() {

    private var items: List<SitePermission> = emptyList()

    fun submitList(newItems: List<SitePermission>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_permission, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.origin.text = item.origin
        val typeLabel = when (item.type) {
            "camera" -> holder.itemView.context.getString(R.string.permission_camera)
            "mic" -> holder.itemView.context.getString(R.string.permission_mic)
            "location" -> holder.itemView.context.getString(R.string.permission_location)
            else -> item.type
        }
        val statusLabel = if (item.granted) {
            holder.itemView.context.getString(R.string.permission_allow)
        } else {
            holder.itemView.context.getString(R.string.permission_deny)
        }
        holder.type.text = "$typeLabel · $statusLabel"
        holder.icon.setImageResource(
            when (item.type) {
                "camera" -> R.drawable.ic_camera
                "mic" -> R.drawable.ic_mic
                else -> R.drawable.ic_location
            }
        )
        holder.deleteBtn.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount(): Int = items.size

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val origin: TextView = itemView.findViewById(R.id.permOrigin)
        val type: TextView = itemView.findViewById(R.id.permType)
        val icon: ImageView = itemView.findViewById(R.id.permIcon)
        val deleteBtn: View = itemView.findViewById(R.id.btnPermDelete)
    }
}
