package com.yunze.browser

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import com.yunze.browser.databinding.ActivitySettingsBinding
import com.yunze.browser.databinding.SettingSwitchItemBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var dataStore: DataStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dataStore = DataStore(this)
        binding.btnBack.setOnClickListener { finish() }

        addSwitchRow(
            binding.rowAdBlock,
            getString(R.string.setting_ad_block),
            getString(R.string.setting_ad_block_desc),
            dataStore.adBlockEnabled
        ) { dataStore.adBlockEnabled = it }

        addSwitchRow(
            binding.rowHttpsUpgrade,
            getString(R.string.setting_https_upgrade),
            getString(R.string.setting_https_upgrade_desc),
            dataStore.httpsUpgradeEnabled
        ) { dataStore.httpsUpgradeEnabled = it }

        addSwitchRow(
            binding.rowPopupBlock,
            getString(R.string.setting_popup_block),
            getString(R.string.setting_popup_block_desc),
            dataStore.popupBlockEnabled
        ) { dataStore.popupBlockEnabled = it }

        addSwitchRow(
            binding.rowDoNotTrack,
            getString(R.string.setting_do_not_track),
            getString(R.string.setting_do_not_track_desc),
            dataStore.doNotTrackEnabled
        ) { dataStore.doNotTrackEnabled = it }

        addSwitchRow(
            binding.rowJs,
            getString(R.string.setting_js),
            getString(R.string.setting_js_desc),
            dataStore.javaScriptEnabled
        ) { dataStore.javaScriptEnabled = it }

        binding.rowPermissions.setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }

        updateSearchEngineLabel()
        binding.rowSearchEngine.setOnClickListener { showSearchEngineDialog() }

        binding.btnClearAllData.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.clear_all_data)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    dataStore.clearAllData()
                    android.webkit.CookieManager.getInstance().removeAllCookies(null)
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    private fun addSwitchRow(
        container: android.widget.LinearLayout,
        title: String,
        desc: String,
        initial: Boolean,
        onChange: (Boolean) -> Unit
    ) {
        val itemBinding = SettingSwitchItemBinding.inflate(layoutInflater, container, true)
        itemBinding.settingTitle.text = title
        itemBinding.settingDesc.text = desc
        itemBinding.settingSwitch.isChecked = initial
        itemBinding.settingSwitch.setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    private fun updateSearchEngineLabel() {
        binding.searchEngineValue.text = SearchEngine.fromId(dataStore.searchEngine).displayName
    }

    private fun showSearchEngineDialog() {
        val engines = SearchEngine.values()
        val names = engines.map { it.displayName }.toTypedArray()
        val currentIndex = engines.indexOfFirst { it.id == dataStore.searchEngine }.coerceAtLeast(0)

        AlertDialog.Builder(this)
            .setTitle(R.string.setting_search_engine)
            .setSingleChoiceItems(names, currentIndex) { dialog, which ->
                dataStore.searchEngine = engines[which].id
                updateSearchEngineLabel()
                dialog.dismiss()
            }
            .show()
    }
}
