package com.yunze.browser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class TabAdapter(
    private val onTabClick: (Int) -> Unit,
    private val onTabClose: (Int) -> Unit
) : RecyclerView.Adapter<TabAdapter.TabViewHolder>() {

    private var tabs: List<BrowserTabModel> = emptyList()

    fun submitList(newTabs: List<BrowserTabModel>) {
        tabs = newTabs
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TabViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tab, parent, false)
        return TabViewHolder(view)
    }

    override fun onBindViewHolder(holder: TabViewHolder, position: Int) {
        val tab = tabs[position]
        holder.title.text = tab.title.ifBlank { "Yeni Sekme" }
        holder.url.text = tab.url
        holder.incognitoIndicator.visibility = if (tab.isIncognito) View.VISIBLE else View.GONE
        holder.icon.setImageResource(if (tab.isIncognito) R.drawable.ic_incognito else R.drawable.ic_search)

        holder.itemView.setOnClickListener { onTabClick(position) }
        holder.closeButton.setOnClickListener { onTabClose(position) }
    }

    override fun getItemCount(): Int = tabs.size

    class TabViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: android.widget.TextView = itemView.findViewById(R.id.tabTitle)
        val url: android.widget.TextView = itemView.findViewById(R.id.tabUrl)
        val icon: android.widget.ImageView = itemView.findViewById(R.id.tabIcon)
        val incognitoIndicator: View = itemView.findViewById(R.id.incognitoIndicator)
        val closeButton: View = itemView.findViewById(R.id.btnCloseTab)
    }
}
